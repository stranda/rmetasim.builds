/* This file is part of Metasim
   This file is the implementation of the landscape global Allele lookup table
*/

/* includes */
#include <AlleleTbl.h>


/*

   Begin implementation of allele table

 */

AlleleLookTbl::AlleleLookTbl()
{
}
AlleleLookTbl::~AlleleLookTbl()
{
  clear();
}

void AlleleLookTbl::push_back(AlleleTbl * atp)
{
  Atbl.push_back(atp);
}

void AlleleLookTbl::clear()
{
  int asz,i;
#ifdef RDEBUG
  cerr << "deleting Atbl[i]" <<endl;
  cerr << "ntbls"<<Atbl.size()<<endl;
#endif
  asz = size();
  if (asz>0)
    {
      for (i=0;i<asz;i++)
	{
#ifdef RDEBUG
	  cerr << "Cleaning  Atbl[i] i= "<<i <<endl;
#endif
	  delete Atbl[i];
	}
      Atbl.resize(0);
    }
}


void AlleleLookTbl::DummyFreq(int ps)
{
  size_t i;
  for (i=0;i<size();i++)
    Atbl[i]->dummyfreq(ps);
}

void AlleleLookTbl::ZeroFreq()
{
  size_t i;
  for (i=0;i<Atbl.size();i++)
    Atbl[i]->zerofreq();
}


//AlleleLookTbl Atbls;

/*
;;; Local Variables: ***
;;; mode: C++ ***
;;; minor-mode:  font-lock  ***
;;; End:  ***
*/




